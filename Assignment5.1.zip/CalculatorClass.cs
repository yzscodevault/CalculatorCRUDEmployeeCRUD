﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment5._1
{
    enum Operator
    {
        Addition,
        Substraction,
        Muplication,
        Division
    }

    class CalculatorClass
    {
        public decimal FstNum { get; set; }
        public Operator Operation { get; set; }
        public decimal ScdNum { get; set; }
        public decimal Result { get; set; }
    }
}
